import { createContext } from 'react';

const LoggerContext = createContext(null);

export default LoggerContext;
