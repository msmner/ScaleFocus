const defaultListId = 1;

export default defaultListId;
